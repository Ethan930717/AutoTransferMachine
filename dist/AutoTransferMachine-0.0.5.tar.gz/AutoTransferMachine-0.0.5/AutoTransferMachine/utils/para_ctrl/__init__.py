#import upload_machine.utils.para_ctrl.readyaml
#import upload_machine.utils.para_ctrl.readargs

#readyaml = upload_machine.utils.para_ctrl.readyaml.readyaml
#readargs = upload_machine.utils.para_ctrl.readargs.readargs

