#!/bin/bash
#定义变量
atm_path=/usr/local/lib/python3.9/dist-packages/AutoTransferMachine #atm文件夹的路径
git_url=https://github.com/Ethan930717/AutoTransferMachine #GitHub仓库的URL
rm -rf $atm_path
git clone $git_url $atm_path
echo "ATM sync complete!"